/* 파일 : BookStoreStarter.java			*
 * 과목명 : 객체지향시스템분석및설꼐			*
 * 서술 : 메인 메소드가 있는 클래스			*/
import boundary.MainFrame;

public class BookStoreStarter {

	public static void main(String[] args) {
		new MainFrame("BookStore");
	}
}